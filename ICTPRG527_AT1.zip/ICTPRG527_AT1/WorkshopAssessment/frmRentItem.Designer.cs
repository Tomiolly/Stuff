﻿
namespace WorkshopAssessment
{
    partial class frmRentItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblSurname = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtCustomerId = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblCurrentAccount = new System.Windows.Forms.Label();
            this.btnReturnTool = new System.Windows.Forms.Button();
            this.lblCurrentWorkspace = new System.Windows.Forms.Label();
            this.cbxCurrentWorkspace = new System.Windows.Forms.ComboBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvTools = new System.Windows.Forms.DataGridView();
            this.btnAddToAccount = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.dgvCurrentAccount = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTools)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCurrentAccount)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(42, 40);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(21, 13);
            this.lblCustomerID.TabIndex = 0;
            this.lblCustomerID.Text = "ID:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(42, 66);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 13);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name:";
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Location = new System.Drawing.Point(42, 92);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(52, 13);
            this.lblSurname.TabIndex = 2;
            this.lblSurname.Text = "Surname:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(42, 118);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(41, 13);
            this.lblPhone.TabIndex = 3;
            this.lblPhone.Text = "Phone:";
            // 
            // txtCustomerId
            // 
            this.txtCustomerId.Location = new System.Drawing.Point(97, 40);
            this.txtCustomerId.Name = "txtCustomerId";
            this.txtCustomerId.ReadOnly = true;
            this.txtCustomerId.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerId.TabIndex = 4;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(97, 66);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(100, 20);
            this.txtName.TabIndex = 5;
            // 
            // txtSurname
            // 
            this.txtSurname.Location = new System.Drawing.Point(97, 92);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.ReadOnly = true;
            this.txtSurname.Size = new System.Drawing.Size(100, 20);
            this.txtSurname.TabIndex = 6;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(97, 118);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.ReadOnly = true;
            this.txtPhone.Size = new System.Drawing.Size(100, 20);
            this.txtPhone.TabIndex = 7;
            // 
            // lblCurrentAccount
            // 
            this.lblCurrentAccount.AutoSize = true;
            this.lblCurrentAccount.Location = new System.Drawing.Point(42, 191);
            this.lblCurrentAccount.Name = "lblCurrentAccount";
            this.lblCurrentAccount.Size = new System.Drawing.Size(105, 13);
            this.lblCurrentAccount.TabIndex = 8;
            this.lblCurrentAccount.Text = "Currently on account";
            // 
            // btnReturnTool
            // 
            this.btnReturnTool.Location = new System.Drawing.Point(45, 357);
            this.btnReturnTool.Name = "btnReturnTool";
            this.btnReturnTool.Size = new System.Drawing.Size(75, 23);
            this.btnReturnTool.TabIndex = 10;
            this.btnReturnTool.Text = "Return Tool";
            this.btnReturnTool.UseVisualStyleBackColor = true;
            // 
            // lblCurrentWorkspace
            // 
            this.lblCurrentWorkspace.AutoSize = true;
            this.lblCurrentWorkspace.Location = new System.Drawing.Point(379, 40);
            this.lblCurrentWorkspace.Name = "lblCurrentWorkspace";
            this.lblCurrentWorkspace.Size = new System.Drawing.Size(99, 13);
            this.lblCurrentWorkspace.TabIndex = 11;
            this.lblCurrentWorkspace.Text = "Current Workspace";
            // 
            // cbxCurrentWorkspace
            // 
            this.cbxCurrentWorkspace.FormattingEnabled = true;
            this.cbxCurrentWorkspace.Location = new System.Drawing.Point(382, 56);
            this.cbxCurrentWorkspace.Name = "cbxCurrentWorkspace";
            this.cbxCurrentWorkspace.Size = new System.Drawing.Size(227, 21);
            this.cbxCurrentWorkspace.TabIndex = 12;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(379, 118);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(44, 13);
            this.lblSearch.TabIndex = 13;
            this.lblSearch.Text = "Search:";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(433, 118);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(176, 20);
            this.txtSearch.TabIndex = 14;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // dgvTools
            // 
            this.dgvTools.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTools.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvTools.Location = new System.Drawing.Point(382, 149);
            this.dgvTools.Name = "dgvTools";
            this.dgvTools.Size = new System.Drawing.Size(227, 202);
            this.dgvTools.TabIndex = 15;
            this.dgvTools.DoubleClick += new System.EventHandler(this.dgvTools_DoubleClick);
            // 
            // btnAddToAccount
            // 
            this.btnAddToAccount.Location = new System.Drawing.Point(382, 356);
            this.btnAddToAccount.Name = "btnAddToAccount";
            this.btnAddToAccount.Size = new System.Drawing.Size(114, 23);
            this.btnAddToAccount.TabIndex = 16;
            this.btnAddToAccount.Text = "Add to Account";
            this.btnAddToAccount.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(534, 357);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dgvCurrentAccount
            // 
            this.dgvCurrentAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCurrentAccount.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCurrentAccount.Location = new System.Drawing.Point(45, 207);
            this.dgvCurrentAccount.Name = "dgvCurrentAccount";
            this.dgvCurrentAccount.Size = new System.Drawing.Size(249, 144);
            this.dgvCurrentAccount.TabIndex = 9;
            this.dgvCurrentAccount.DoubleClick += new System.EventHandler(this.dgvCurrentAccount_DoubleClick_1);
            // 
            // frmRentItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 415);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAddToAccount);
            this.Controls.Add(this.dgvTools);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.cbxCurrentWorkspace);
            this.Controls.Add(this.lblCurrentWorkspace);
            this.Controls.Add(this.btnReturnTool);
            this.Controls.Add(this.dgvCurrentAccount);
            this.Controls.Add(this.lblCurrentAccount);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtSurname);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtCustomerId);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblSurname);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblCustomerID);
            this.Name = "frmRentItem";
            this.Text = "Manage Member Rentals";
            this.Load += new System.EventHandler(this.frmSelectRentals_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTools)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCurrentAccount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtCustomerId;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblCurrentAccount;
        private System.Windows.Forms.Button btnReturnTool;
        private System.Windows.Forms.Label lblCurrentWorkspace;
        private System.Windows.Forms.ComboBox cbxCurrentWorkspace;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgvTools;
        private System.Windows.Forms.Button btnAddToAccount;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridView dgvCurrentAccount;
    }
}