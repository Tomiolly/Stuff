﻿using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class FrmStartMenu : Form
    {
        // Global Variables
        Logger logger = LogManager.GetCurrentClassLogger();

        #region Initialisation
        public FrmStartMenu()
        {

            InitializeComponent();
            logger.Info("Troy has logged in!");
            ThatsNotANumber();
        }

        private void ThatsNotANumber()
        {
            try
            {
                string num = "hello";
                int number = int.Parse(num);
            }
            catch (Exception e)
            {
                logger.Error(e, "thats not a number");
            }

        }

        private void FrmStartMenu_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }
        #endregion

        #region Buttons
        private void btnAmmendMembers_Click(object sender, EventArgs e)
        {
            frmClients frmRentalClient = new frmClients();
            frmRentalClient.ShowDialog();
        }

        private void btnManageTools_Click(object sender, EventArgs e)
        {
            frmTools frmTools = new frmTools();
            frmTools.ShowDialog();

        }

        private void btnManageRentals_Click(object sender, EventArgs e)
        {
            frmSelectClient frm = new frmSelectClient();
            frm.ShowDialog();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Color colour = dialog.Color;
                Properties.Settings.Default.Colour = dialog.Color;
                Properties.Settings.Default.Save();
            }
            this.BackColor = Properties.Settings.Default.Colour;
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            frmReturnItem frm = new frmReturnItem();
            frm.ShowDialog();
        }
        #endregion


    }
}

