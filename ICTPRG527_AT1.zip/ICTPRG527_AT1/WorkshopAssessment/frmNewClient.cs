﻿using DataManagement;
using DataManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class frmNewClient : Form
    {
        // Global Variables
        Adapter db = new Adapter();
        RentalClient client = new RentalClient();
        bool isNew = true;

        #region Initialisation
        public frmNewClient()
        {
            InitializeComponent();
        }

        public frmNewClient(int id)
        {
            InitializeComponent();
            LoadSingleEntry(id);
            isNew = false;
        }

        private void LoadSingleEntry(int id)
        {
            client = db.GetSingleClient (id);
            txtClientId.Text = client.clientId.ToString();
            txtFirstName.Text = client.firstName;
            txtLastName.Text = client.lastName;
            txtPhone.Text = client.phone.ToString();
        }

        private void frmNewClient_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }
        #endregion

        #region Buttons
        private void btnSave_Click_1(object sender, EventArgs e)
        {
            RentalClient currentClient = new RentalClient();

            if (isNew)
            {
                currentClient.firstName = txtFirstName.Text;
                currentClient.lastName = txtLastName.Text;
                currentClient.phone = int.Parse(txtPhone.Text);

                db.AddNewClientData(currentClient);
                this.Close();
            }
            else
            {
                currentClient.clientId = int.Parse(txtClientId.Text);
                currentClient.firstName = txtFirstName.Text;
                currentClient.lastName = txtLastName.Text;
                currentClient.phone = int.Parse(txtPhone.Text);
                db.UpdateClient(currentClient);
                this.Close();
            }

        }

        #endregion
    }
}
