﻿using DataManagement;
using DataManagement.Models;
using DataManagement.View_Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class frmRentItem : Form
    {
        // Global Variable
        Adapter db = new Adapter();
        RentalClient client = new RentalClient();
    
        
        List<Locations> locations = new List<Locations>();
        bool isNew = true;

        List<Tools> currentTools;
        List<Tools> availableTools = new List<Tools>();
        List<Tools> filteredTools = new List<Tools>();

        List<Tools> activeLoans = new List<Tools>();

        #region Initialisation
        public frmRentItem()
        {
            InitializeComponent();
        }

        public frmRentItem(int id)
        {
            InitializeComponent();
            LoadSingleEntry(id);
            LoadLocations();
            LoadRentedTools();
            LoadInventoryTable();
            isNew = false;

        }

        private void LoadSingleEntry(int id)
        {
            client = db.GetSingleClient(id);
            txtCustomerId.Text = client.clientId.ToString();
            txtName.Text = client.firstName;
            txtSurname.Text = client.lastName;
            txtPhone.Text = client.phone.ToString();
        }
        private void LoadLocations()
        {
            locations = db.GetLocations();
            cbxCurrentWorkspace.DataSource = locations;
            cbxCurrentWorkspace.DisplayMember = "location";
            cbxCurrentWorkspace.ValueMember = "locationId";
        }

        private void LoadInventoryTable()
        {
            availableTools = db.GetAvailableInventory(1);
            currentTools = availableTools;
            dgvTools.DataSource = currentTools;
            dgvTools.Columns["status"].Visible = false;
            //dgvTools.Columns["toolType"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void LoadRentedTools()
        {
            //int id = (int)cboMembers.SelectedValue;
            dgvCurrentAccount.DataSource = activeLoans;
     
        }

        private void frmSelectRentals_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }

        #endregion

        #region Buttons
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            filteredTools.Clear();
            if (!String.IsNullOrEmpty(txtSearch.Text))
            {
                foreach (var item in availableTools)
                {
                    if ((item.toolType.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (item.brandName.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        filteredTools.Add(item);
                    }
                }
                currentTools = filteredTools;
            }
            else
            {
                currentTools = availableTools;
            }
            UpdateTables();
        }

        private void dgvTools_DoubleClick(object sender, EventArgs e)
        {
            if (dgvTools.RowCount < 1)
            {
                return;
            }
            Tools item = currentTools[dgvTools[0, dgvTools.CurrentCell.RowIndex].RowIndex];

            //Need to remove datasources before modifying lists to avoid error.
            dgvTools.DataSource = null;
            dgvCurrentAccount.DataSource = null;
            activeLoans.Add(item);
            currentTools.Remove(item);
            UpdateTables();
        }

        private void dgvCurrentAccount_DoubleClick(object sender, EventArgs e)
        {
            if (dgvCurrentAccount.RowCount < 1)
            {
                return;
            }
            Tools item = activeLoans[dgvCurrentAccount[0, dgvCurrentAccount.CurrentCell.RowIndex].RowIndex];

            //Need to remove datasources before modifying lists to avoid error.
            dgvTools.DataSource = null;
            dgvCurrentAccount.DataSource = null;
            currentTools.Add(item);
            activeLoans.Remove(item);


            UpdateTables();
        }
        private void dgvCurrentAccount_DoubleClick_1(object sender, EventArgs e)
        {
            if (dgvCurrentAccount.RowCount < 1)
            {
                return;
            }
            Tools item = activeLoans[dgvCurrentAccount[0, dgvCurrentAccount.CurrentCell.RowIndex].RowIndex];

            //Need to remove datasources before modifying lists to avoid error.
            dgvTools.DataSource = null;
            dgvCurrentAccount.DataSource = null;
            currentTools.Add(item);
            activeLoans.Remove(item);
            UpdateTables();
        }
        #endregion

        #region Methods
        private void UpdateTables()
        {
            currentTools = currentTools.OrderBy(InventoryItem => InventoryItem.toolId).ToList();

            dgvTools.DataSource = currentTools;
            var temp = new BindingList<Tools>();
            temp.AllowEdit = false;
            foreach(var tool in activeLoans)
            {
                temp.Add(tool);
            }
            dgvCurrentAccount.DataSource = temp;

            dgvTools.Columns["status"].Visible = false;
            //dgvTools.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            //Repeat above for selected dataview
            dgvCurrentAccount.Columns["status"].Visible = false;
            //dgvCurrentAccount.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }
        #endregion


    }
}
