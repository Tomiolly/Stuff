﻿
namespace WorkshopAssessment
{
    partial class FrmStartMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnManageTools = new System.Windows.Forms.Button();
            this.btnAmmendMembers = new System.Windows.Forms.Button();
            this.btnRentItem = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSettings
            // 
            this.btnSettings.Location = new System.Drawing.Point(28, 150);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(152, 63);
            this.btnSettings.TabIndex = 2;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnManageTools
            // 
            this.btnManageTools.Location = new System.Drawing.Point(186, 12);
            this.btnManageTools.Name = "btnManageTools";
            this.btnManageTools.Size = new System.Drawing.Size(152, 63);
            this.btnManageTools.TabIndex = 4;
            this.btnManageTools.Text = "Manage Tools";
            this.btnManageTools.UseVisualStyleBackColor = true;
            this.btnManageTools.Click += new System.EventHandler(this.btnManageTools_Click);
            // 
            // btnAmmendMembers
            // 
            this.btnAmmendMembers.Location = new System.Drawing.Point(28, 12);
            this.btnAmmendMembers.Name = "btnAmmendMembers";
            this.btnAmmendMembers.Size = new System.Drawing.Size(152, 63);
            this.btnAmmendMembers.TabIndex = 5;
            this.btnAmmendMembers.Text = "Manage Customers";
            this.btnAmmendMembers.UseVisualStyleBackColor = true;
            this.btnAmmendMembers.Click += new System.EventHandler(this.btnAmmendMembers_Click);
            // 
            // btnRentItem
            // 
            this.btnRentItem.Location = new System.Drawing.Point(28, 81);
            this.btnRentItem.Name = "btnRentItem";
            this.btnRentItem.Size = new System.Drawing.Size(152, 63);
            this.btnRentItem.TabIndex = 6;
            this.btnRentItem.Text = "Rent an Item";
            this.btnRentItem.UseVisualStyleBackColor = true;
            this.btnRentItem.Click += new System.EventHandler(this.btnManageRentals_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(186, 150);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 63);
            this.button1.TabIndex = 7;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(186, 81);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(152, 63);
            this.btnReturn.TabIndex = 8;
            this.btnReturn.Text = "Return an Item";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // FrmStartMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 245);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnRentItem);
            this.Controls.Add(this.btnAmmendMembers);
            this.Controls.Add(this.btnManageTools);
            this.Controls.Add(this.btnSettings);
            this.Name = "FrmStartMenu";
            this.Text = "Tool Rental";
            this.Load += new System.EventHandler(this.FrmStartMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnManageTools;
        private System.Windows.Forms.Button btnAmmendMembers;
        private System.Windows.Forms.Button btnRentItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnReturn;
    }
}

