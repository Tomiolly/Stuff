﻿using DataManagement;
using DataManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class frmSelectClient : Form
    {
        // Global Variables
        List<RentalClient> customers = new List<RentalClient>();
        Adapter db = new Adapter();

        #region Initialisation
        public frmSelectClient()
        {
            InitializeComponent();
            DisplayLoanReport();
        }

        private void DisplayLoanReport()
        {
            customers = db.GetAllMembers();
            dgvCustomers.DataSource = null;
            dgvCustomers.DataSource = customers;
            dgvCustomers.Columns["FirstName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

        }

        private void frmCustomers_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }
        #endregion

        #region Buttons
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvCustomers_DoubleClick(object sender, EventArgs e)
        {
            int Id;
            Id = (int)dgvCustomers[0, dgvCustomers.CurrentCell.RowIndex].Value;
            frmRentItem frm = new frmRentItem(Id);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                DisplayLoanReport();
            }
        }
        #endregion


    }
}
