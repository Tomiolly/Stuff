﻿using DataManagement;
using DataManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class frmTools : Form
    {
        // Global Variables
        List<Tools> tools = new List<Tools>();
        Adapter db = new Adapter();

        #region Initialisation
        public frmTools()
        {
            InitializeComponent();
            LoadToolTable();
        }

        private void DisplayTools()
        {
            tools = db.GetAllTools();
            dgvTools.DataSource = null;
            dgvTools.DataSource = tools;
        }

        private void FrmTools_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }
        #endregion

        #region Buttons
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            List<Tools> filteredList = new List<Tools>();
            filteredList.Clear();
            if (!String.IsNullOrEmpty(txtSearch.Text))
            {
                foreach (var item in tools)
                {
                    if ((item.toolType.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (item.brandName.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        filteredList.Add(item);
                    }
                }
                dgvTools.DataSource = filteredList;
            }
            else
            {
                dgvTools.DataSource = tools;
            }
        }

        private void btnDeleteTool_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dgvTools[0, dgvTools.CurrentCell.RowIndex].Value.ToString());
            if (dgvTools.RowCount > 0)
            {
                DialogResult response = MessageBox.Show("Delete this Tool?", "Confirmation", MessageBoxButtons.YesNo);
                if (response == DialogResult.Yes)
                {
                    db.DeleteToolItem(id);
                    LoadToolTable();
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddTool_Click(object sender, EventArgs e)
        {
            frmNewTool frm = new frmNewTool();
            if(frm.ShowDialog() == DialogResult.OK)
            {
                LoadToolTable();
            }

        }
        #endregion

        #region Methods
        private void LoadToolTable()
        {
            tools = db.GetAllTools();
            dgvTools.DataSource = tools;

            dgvTools.Columns["toolId"].Visible = false; //Hides FullName column from datagridview
            dgvTools.Columns["brandName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; //Expands Email Column to fill empty space in datagridview.
        }
        #endregion


    }
}
