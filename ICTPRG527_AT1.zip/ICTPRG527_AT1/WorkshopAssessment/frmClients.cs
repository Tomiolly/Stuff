﻿using DataManagement;
using DataManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class frmClients : Form
    {
        // Global Variables

        //Instanciate a new list of rental clients
        List<RentalClient> rentalClients = new List<RentalClient>();
        //Instanciate the adapter class
        Adapter db = new Adapter();

        #region Initialisation
        public frmClients()
        {
            InitializeComponent();
            //Displays the rental clients upon initalisation
            DisplayLoanReport();
        }

        //Displays members from rentalClient in the data grid view
        private void DisplayLoanReport()
        {
            // Gathers all rentalClients from the datanase
            rentalClients = db.GetAllMembers();
            // Clears the data grid view
            dgvCustomers.DataSource = null;
            // Adds rentalClients to the data grid view
            dgvCustomers.DataSource = rentalClients;
            // fills the data grid view so theres no empty space
            dgvCustomers.Columns["FirstName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }
        private void frmRentals_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }
        #endregion

        #region Buttons
        // Closes the application
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            List<RentalClient> filteredList = new List<RentalClient>();
            filteredList.Clear();
            if (!String.IsNullOrEmpty(txtSearch.Text))
            {
                foreach (var item in rentalClients)
                {
                    if ((item.firstName.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (item.lastName.IndexOf(txtSearch.Text, StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        filteredList.Add(item);
                    }
                }
                dgvCustomers.DataSource = filteredList;
            }
            else
            {
                dgvCustomers.DataSource = rentalClients;
            }
        }

        private void btnSelectMember_Click(object sender, EventArgs e)
        {
            frmNewClient frm = new frmNewClient();
            if (frm.ShowDialog() == DialogResult.OK)
            {
                DisplayLoanReport();
            }

        }

        private void dgvCustomers_DoubleClick(object sender, EventArgs e)
        {
            int Id;
            Id = (int)dgvCustomers[0, dgvCustomers.CurrentCell.RowIndex].Value;
            frmNewClient frm = new frmNewClient(Id);
            if (frm.ShowDialog() == DialogResult.OK)
            {
                DisplayLoanReport();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you sure you wish to delete this?", "Confirmation", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                int Id;
                Id = int.Parse(dgvCustomers[0, dgvCustomers.CurrentCell.RowIndex].Value.ToString());
                db.DeleteInventoryItem(Id);
                DisplayLoanReport();
            }

        }
        #endregion


    }
}
