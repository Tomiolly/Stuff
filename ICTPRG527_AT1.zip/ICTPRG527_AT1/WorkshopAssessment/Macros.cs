﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkshopAssessment
{
    class Macros
    {
        #region Button Events

        #endregion

        #region Form Events

        #endregion

        #region Helper Methods

        #endregion




    }
}
