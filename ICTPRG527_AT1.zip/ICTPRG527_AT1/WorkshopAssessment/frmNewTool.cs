﻿using DataManagement;
using DataManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopAssessment
{
    public partial class frmNewTool : Form
    {
        // Global Variables
        Adapter db = new Adapter();
        Tools tools = new Tools();
        bool isNew = true;

        #region Initialisation
        public frmNewTool()
        {
            InitializeComponent();
        }

        public frmNewTool(int id)
        {
            InitializeComponent();
            LoadSingleEntry(id);
            isNew = false;
        }

        private void LoadSingleEntry(int id)
        {
            tools = db.GetSingleTool(id);
            txtType.Text = tools.toolType;
            txtBrand.Text = tools.brandName;
            txtComment.Text = tools.comments;
           
        }

        private bool CheckFieldsFilled()
        {
            if (String.IsNullOrWhiteSpace(txtType.Text))
            {
                return false;
            }
            if (String.IsNullOrWhiteSpace(txtBrand.Text))
            {
                return false;
            }

            return true;
        }

        private void frmNewTool_Load(object sender, EventArgs e)
        {
            this.BackColor = Properties.Settings.Default.Colour;
        }
        #endregion

        #region Buttons

        private void btnAdd_Click(object sender, EventArgs e)
        {

            if (CheckFieldsFilled())
            {
                tools.toolType = txtType.Text;
                tools.brandName = txtBrand.Text;
                tools.comments = txtComment.Text;
                tools.status = int.Parse(txtStatus.Text);

                if (isNew)
                {
                    db.AddTool(tools);
                }
                else
                {
                    tools.toolId = int.Parse(txtToolId.Text);
                    db.UpdateTool(tools);
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Please Complete All Relevant Fields Before Saving!");
            }            
        }
        #endregion


    }
}
