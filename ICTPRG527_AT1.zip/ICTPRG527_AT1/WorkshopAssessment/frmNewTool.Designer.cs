﻿
namespace WorkshopAssessment
{
    partial class frmNewTool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNewTool = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblBrand = new System.Windows.Forms.Label();
            this.lblCommen = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtBrand = new System.Windows.Forms.TextBox();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblToolId = new System.Windows.Forms.Label();
            this.txtToolId = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNewTool
            // 
            this.lblNewTool.AutoSize = true;
            this.lblNewTool.Location = new System.Drawing.Point(123, 25);
            this.lblNewTool.Name = "lblNewTool";
            this.lblNewTool.Size = new System.Drawing.Size(78, 13);
            this.lblNewTool.TabIndex = 0;
            this.lblNewTool.Text = "Add a new tool";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(62, 48);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(58, 13);
            this.lblType.TabIndex = 1;
            this.lblType.Text = "Tool Type:";
            // 
            // lblBrand
            // 
            this.lblBrand.AutoSize = true;
            this.lblBrand.Location = new System.Drawing.Point(51, 79);
            this.lblBrand.Name = "lblBrand";
            this.lblBrand.Size = new System.Drawing.Size(69, 13);
            this.lblBrand.TabIndex = 2;
            this.lblBrand.Text = "Brand Name:";
            // 
            // lblCommen
            // 
            this.lblCommen.AutoSize = true;
            this.lblCommen.Location = new System.Drawing.Point(61, 113);
            this.lblCommen.Name = "lblCommen";
            this.lblCommen.Size = new System.Drawing.Size(59, 13);
            this.lblCommen.TabIndex = 3;
            this.lblCommen.Text = "Comments:";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(126, 48);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(100, 20);
            this.txtType.TabIndex = 4;
            // 
            // txtBrand
            // 
            this.txtBrand.Location = new System.Drawing.Point(126, 79);
            this.txtBrand.Name = "txtBrand";
            this.txtBrand.Size = new System.Drawing.Size(100, 20);
            this.txtBrand.TabIndex = 5;
            // 
            // txtComment
            // 
            this.txtComment.Location = new System.Drawing.Point(126, 113);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(167, 76);
            this.txtComment.TabIndex = 6;
            // 
            // btnAdd
            // 
            this.btnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAdd.Location = new System.Drawing.Point(126, 213);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 7;
            this.btnAdd.Text = "Add Tool";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(13, 257);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(115, 13);
            this.lblStatus.TabIndex = 8;
            this.lblStatus.Text = "status (need to fix this):";
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(126, 254);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(22, 20);
            this.txtStatus.TabIndex = 9;
            this.txtStatus.Text = "0";
            // 
            // lblToolId
            // 
            this.lblToolId.AutoSize = true;
            this.lblToolId.Location = new System.Drawing.Point(250, 25);
            this.lblToolId.Name = "lblToolId";
            this.lblToolId.Size = new System.Drawing.Size(43, 13);
            this.lblToolId.TabIndex = 10;
            this.lblToolId.Text = "Tool Id:";
            // 
            // txtToolId
            // 
            this.txtToolId.Location = new System.Drawing.Point(300, 25);
            this.txtToolId.Name = "txtToolId";
            this.txtToolId.ReadOnly = true;
            this.txtToolId.Size = new System.Drawing.Size(58, 20);
            this.txtToolId.TabIndex = 11;
            // 
            // frmNewTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 282);
            this.Controls.Add(this.txtToolId);
            this.Controls.Add(this.lblToolId);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtComment);
            this.Controls.Add(this.txtBrand);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.lblCommen);
            this.Controls.Add(this.lblBrand);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblNewTool);
            this.Name = "frmNewTool";
            this.Text = "frmNewTool";
            this.Load += new System.EventHandler(this.frmNewTool_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNewTool;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblBrand;
        private System.Windows.Forms.Label lblCommen;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtBrand;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label lblToolId;
        private System.Windows.Forms.TextBox txtToolId;
    }
}