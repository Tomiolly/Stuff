﻿using DataManagement;
using DataManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkshopAssessment
{   
    public class Initialiser
    {
        // Global Variables
        Adapter db = new Adapter();
     
        public void InitialiseDatabase()
        {
            //Helpers.DeleteDatabase();
            Helper.CreateDatabase();
            //CreateTables();

            if (!Helper.DoTablesExist())
            {
                CreateTables();
                SeedTables();
            }
        }

        #region Create Tables
        private void CreateTables()
        {
            CreateToolsTable();
            CreateClientTable();
            CreateLocationTable();
            CreateRentalTable();
        }

        /// <summary>
        /// Creates Tools
        /// </summary>
        private void CreateToolsTable()
        {
            string schema = "toolId int IDENTITY(1,1) PRIMARY KEY, " +
                            "toolType VARCHAR(50), " +
                            "brandName VARCHAR(50), " +
                            "status int, " +
                            "comments VARCHAR(MAX)";

            Helper.CreateTable("Tools", schema);
        }

        private void CreateClientTable()
        {
            string schema = "clientId int IDENTITY(1,1) PRIMARY KEY, " +
                            "firstName VARCHAR(50), " +
                            "lastName VARCHAR(50), " +
                            "phone int";

            Helper.CreateTable("RentalClient", schema);
        }

        private void CreateLocationTable()
        {
            string schema = "locationId int IDENTITY(1,1) PRIMARY KEY, " +
                            "location VARCHAR(50)";

            Helper.CreateTable("Locations", schema);
        }

        private void CreateRentalTable()
        {
            string schema = "rentalId int IDENTITY(1,1) PRIMARY KEY, " +
                            "clientId int, " +
                            "toolId int, " +
                            "locationId int, " +
                            "notes VARCHAR(50), " +
                            "dateRented DATETIME, " +
                            "dateReturned DATETIME, " +
                            "FOREIGN KEY(locationId) REFERENCES Locations(locationId), " +
                            "FOREIGN KEY(clientId) REFERENCES RentalClient(clientId), " +
                            "FOREIGN KEY(toolId) REFERENCES Tools(toolId)"; 

            Helper.CreateTable("Rentals", schema);
        }
        #endregion

        #region Seed Tables
        private void SeedTables()
        {
            SeedToolsTable();
            SeedClientsTable();
            SeedLocationTable();
            SeedLoanTable();
        }

        /// <summary>
        /// Seeds Tools
        /// </summary>
        private void SeedToolsTable()
        {
            List<Tools> toolSeed = new List<Tools>
                { new Tools
                {
                    toolType = "Screwdriver",
                    brandName = "Karcher",
                    status = 0,
                    comments = "Pressure washing screwdriver"
                },
                { new Tools
                {
                    toolType = "Gun",
                    brandName = "Sword",
                    status = 0,
                    comments = "Daring, aren't we?"
                } },
                { new Tools
                {
                    toolType = "Cart",
                    brandName = "MineCart",
                    status = 1,
                    comments = "A minors cart"
                }
            },
            { new Tools
                {
                    toolType = "Tripod",
                    brandName = "HHHH",
                    status = 1,
                    comments = "A Camera Stand"
                }
            },
                { new Tools
                {
                    toolType = "Car",
                    brandName = "BigCar",
                    status = 1,
                    comments = "A Large car"
                }
            }
            };

            foreach (var tool in toolSeed)
            {
                db.AddTool(tool);
            }
        }

        private void SeedClientsTable()
        {
            List<RentalClient> clientSeed = new List<RentalClient>
                { new RentalClient
                {
                    firstName = "Thomas",
                    lastName = "Abreu",
                    phone = 14545
                },
                { new RentalClient
                {
                    firstName = "Homer",
                    lastName = "Simpson",
                    phone = 454545
                }
            }   };

            foreach (var client in clientSeed)
            {
                db.AddNewClientData(client);
            }
        }

        private void SeedLocationTable()
        {
            List<Locations> locationSeed = new List<Locations>
                { new Locations
                {
                    location = "Tafe"
                },
                { new Locations
                {
                    location = "Bunnings"
                }
            }   };

            foreach (var location in locationSeed)
            {
                db.AddLocation(location);
            }
        }

        private void SeedLoanTable()
        {
            List<Rentals> newRentals = new List<Rentals>();
            newRentals.Add(new Rentals { clientId = 1, toolId = 1, locationId = 1, dateRented = System.DateTime.Now.AddDays(-7).AddHours(-12) });
            newRentals.Add(new Rentals { clientId = 2, toolId = 2, locationId = 2, dateRented = System.DateTime.Now.AddDays(-3).AddHours(-3) });


            foreach (var item in newRentals)
            {
                db.SaveNewRental(item);
            }
        }
        #endregion

    }
}
