﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DataManagement.Models;
using DataManagement.View_Models;
using NLog;

namespace DataManagement
{
    public class Adapter
    {

        #region Client
        /// <summary>
        /// Uses an SQL to get all Client Data
        /// </summary>
        /// <returns></returns>
        public List<RentalClient> GetAllMembers()
        {
            string sql = "SELECT * FROM RentalClient";
            using (var connection = Helper.GetConnection())
            {
                return connection.Query<RentalClient>(sql).ToList();
            }
        }

        /// <summary>
        /// Deletes a clients entry from the database
        /// </summary>
        /// <param name="ID"></param>
        public void DeleteInventoryItem(int ID)
        {
            string sql = $"DELETE FROM RentalClient WHERE clientId = {ID}";
            using (var connection = Helper.GetConnection())
            {
                connection.Execute(sql);
            }
        }
        /// <summary>
        /// Retrieves a single client from the database
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public RentalClient GetSingleClient(int clientId)
        {
            string sql = $"SELECT * FROM RentalClient WHERE RentalClient.clientId = {clientId}";
            using (var connection = Helper.GetConnection())
            {
                return connection.QuerySingle<RentalClient>(sql);
            }

        }

        /// <summary>
        /// Adds a client to the database
        /// </summary>
        /// <param name="newClient"></param>
        public void AddNewClientData(RentalClient newClient)
        {
            string sql = $"INSERT INTO RentalClient (firstName, lastName, Phone) VALUES (@firstName, @lastName, @Phone)";
            using (var connection = Helper.GetConnection())
            {
                connection.Execute(sql, newClient);
            }

        }

        /// <summary>
        /// Updates a pre-existing entry in the client database
        /// </summary>
        /// <param name="updatedClient"></param>
        /// <returns></returns>
        public int UpdateClient(RentalClient updatedClient)
        {
            string sql = $"UPDATE RentalClient SET firstName = @firstName, lastName = @lastName, phone = @phone Where clientId = {updatedClient.clientId}";
            int numRows = 0;
            using (var connection = Helper.GetConnection())
            {
                numRows = connection.Execute(sql, updatedClient);
            }
            return numRows;
        }
        #endregion

        #region Tools
        /// <summary>
        /// Gets a single tool from the database
        /// </summary>
        /// <param name="toolId"></param>
        /// <returns></returns>
        public Tools GetSingleTool(int toolId)
        {
            string sql = $"SELECT * FROM Tools WHERE Tools.toolId = {toolId}";
            using (var connection = Helper.GetConnection())
            {
                return connection.QuerySingle<Tools>(sql);
            }

        }

        /// <summary>
        /// Adds a new tool to the database
        /// </summary>
        /// <param name="newTool"></param>
        public void AddNewTool(Tools newTool)
        {
            string sql = $"INSERT INTO Tools (toolType, brandName, comments, status) VALUES (@toolType, @brandName, @comments, @status)";
            using (var connection = Helper.GetConnection())
            {
                connection.Execute(sql, newTool);
            }

        }

        /// <summary>
        /// Updates a tool entry in the database
        /// </summary>
        /// <param name="updatedTool"></param>
        /// <returns></returns>
        public int UpdateTool(Tools updatedTool)
        {
            string sql = $"UPDATE Tools SET toolType = @toolType, brandName = @brandName, comments = @comments, status = @status Where toolId = {updatedTool.toolId}";
            int numRows = 0;
            using (var connection = Helper.GetConnection())
            {
                numRows = connection.Execute(sql, updatedTool);
            }
            return numRows;
        }

        /// <summary>
        /// Retrieves all tools from an SQL database
        /// </summary>
        /// <returns></returns>
        public List<Tools> GetAllTools()
        {
            
            string sql = "SELECT * FROM Tools";
            using (var connection = Helper.GetConnection())
            {
                return connection.Query<Tools>(sql).ToList();
            }

        }

        /// <summary>
        /// Adds a tool to the Database
        /// </summary>
        /// <param name="newTool"></param>
        public void AddTool(Tools newTool)
        {
            string sql = "INSERT INTO Tools " +
                         "(toolType, brandName, status, comments) " +
                         "Values (@toolType, @brandName, @status, @comments) ";
            using (var connection = Helper.GetConnection())
            {
                connection.Execute(sql, newTool);
            }
        }
        
        /// <summary>
        /// Deletes a Tool from the database
        /// </summary>
        /// <param name="ID"></param>
        public void DeleteToolItem(int ID)
        {
            
            try
            {
                string sql = $"DELETE FROM Tools WHERE Tools.toolId = {ID}";
                using (var connection = Helper.GetConnection())
                {
                    connection.Execute(sql);
                }
            }
            catch (Exception e) 
            {
                Console.WriteLine("You cannot delete an item that is being rented.");
            }

        }
        #endregion

        #region Location
        public void AddLocation(Locations newLocation)
        {
            string sql = "INSERT INTO Locations " +
                         "(location) " +
                         "Values (@location) ";
            using (var connection = Helper.GetConnection())
            {
                connection.Execute(sql, newLocation);
            }
        }
        public List<Locations> GetLocations()
        {

            string sql = "SELECT * FROM Locations";
            using (var connection = Helper.GetConnection())
            {
                return connection.Query<Locations>(sql).ToList();
            }

        }
        #endregion

        #region Rentals
        public void SaveNewRental (Rentals rentals)
        {
            string sql = "INSERT INTO Rentals (clientId, toolId, locationId, dateRented) " +
                         "VALUES  (@clientId, @toolId, @locationId, @dateRented) ";
            using (var connection = Helper.GetConnection())
            {
                connection.Execute(sql, rentals);
            }
        }

        public List<Tools> GetAvailableInventory(int status)
        {
            string sql = "SELECT * FROM Tools " +
                        $"WHERE status = {status}";
            using (var connection = Helper.GetConnection())
            {
                return connection.Query<Tools>(sql).ToList();
            }
        }

        public List<RentedTools> ShowCurrentLoansForMember(int id)
        {
            string sql = "SELECT Rentals.rentalId, Tools.toolId, " +
                         "Tools.toolType, Tools.brandName, Tools.comments, Rentals.dateRented " +
                         "FROM Tools INNER JOIN " +
                         "Rentals ON Tools.toolId = Rentals.toolId " +
                         "INNER JOIN " +
                         "RentalClient ON Rentals.clientId = RentalClient.clientId " +
                         "WHERE(Rentals.dateReturned IS NULL) " +
                         $"AND(RentalClient.clientId = {id})";
            using (var connection = Helper.GetConnection())
            {
                return connection.Query<RentedTools>(sql).ToList();
            }
        }
        #endregion
    }
}

