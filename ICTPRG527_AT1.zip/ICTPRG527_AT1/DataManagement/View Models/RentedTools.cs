﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.View_Models
{
    public class RentedTools
    {
        public int rentalId { get; set; }
        public string toolType { get; set; }
        public string brandName { get; set; }
        public string comments { get; set; }
        public DateTime dateRented { get; set; }
        public DateTime? dateReturned { get; set; }
    }
}
