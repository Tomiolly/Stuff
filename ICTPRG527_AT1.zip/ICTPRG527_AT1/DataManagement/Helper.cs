﻿using Dapper;
using DataManagement.Models;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement
{
    public static class Helper
    {
        #region Connection
        /// <summary>
        /// Connection
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string Connection(string name)
        {
            // DESKTOP-FQ67MAC (Home ConnString)
            return ConfigurationManager.ConnectionStrings[name].ConnectionString;
        }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(Connection("WorkshopAssessment"));
        }
        #endregion

        #region Database
        public static void CreateDatabase()
        {
            SqlConnection sqlConnection = GetConnection();
            SqlCommand sqlCommand = new SqlCommand();
            try
            {
                // Create a server connection string which will only have the Data Source (server path) specified to create the database 
                string serverConnectionString = $"Data Source={sqlConnection.DataSource}; " +
                                                $"Integrated Security=True";

                // Check if a database with the same name already exists, if not, create the database, otherwise, do nothing
                string sqlQuery = $"IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = '{sqlConnection.Database}')" +
                                  $"CREATE DATABASE {sqlConnection.Database}";

                // Create a SqlConnection object to connect to a SQL server
                using (SqlConnection connServer = new SqlConnection(serverConnectionString))
                {
                    // Create a SqlCommand object that is needed to executes SQL commands on a database
                    using (sqlCommand = new SqlCommand(sqlQuery, connServer))
                    {
                        // Check if SqlConnection object is Closed before opening, otherwise, an error will occur
                        if (connServer.State == ConnectionState.Closed) connServer.Open();
                        // Run the SQL command
                        int result = sqlCommand.ExecuteNonQuery();
                        // Close the SqlConnection as soon as we are done with it.
                        connServer.Close();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public static bool DoTablesExist()
        {
            var connection = GetConnection();
            string sql = $"SELECT COUNT(*) FROM {connection.Database}.INFORMATION_SCHEMA.TABLES" +
                         $" WHERE TABLE_TYPE = 'BASE TABLE'";
            using (connection)
            {
                int number = connection.QuerySingle<int>(sql);
                if (number > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public static void CreateTable(string tableName, string tableStructure)
        {
            string sql = $"CREATE TABLE {tableName} ({tableStructure})";
            using (var connection = GetConnection())
            {
                try
                {
                    connection.Execute(sql);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }
        #endregion


    }
}
    

