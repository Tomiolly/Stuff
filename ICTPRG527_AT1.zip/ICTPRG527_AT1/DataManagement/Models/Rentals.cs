﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.Models
{
    public class Rentals
    {
        public int toolId { get; set; }
        public int clientId { get; set; }
        public int rentalId { get; set; }
        public int locationId { get; set; }
        public string notes { get; set; }
        public DateTime dateRented {get; set;}
        public DateTime dateReturned { get; set; }
    }
}
