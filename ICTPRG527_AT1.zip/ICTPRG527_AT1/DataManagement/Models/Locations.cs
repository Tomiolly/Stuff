﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.Models
{
    public class Locations
    {
        public int locationId { get; set; }
        public string location { get; set; }
    }
}
