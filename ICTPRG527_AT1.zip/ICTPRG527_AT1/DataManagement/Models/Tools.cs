﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataManagement.Models
{
    public class Tools
    {
        public int toolId { get; set; }
        public string toolType { get; set; }
        public string brandName { get; set; }
        public int status { get; set; }
        public string comments { get; set; }
    }
}
